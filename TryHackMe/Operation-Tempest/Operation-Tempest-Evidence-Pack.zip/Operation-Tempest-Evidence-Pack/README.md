# Operation Tempest — Evidence Pack

This is a safe, portfolio-ready evidence-pack structure for the TryHackMe Operation Tempest investigation.

## Contents
- `Evidence/` — locations for sanitised screenshots, exported event findings, network-analysis notes, and verified indicators.
- `Templates/` — reusable CSV templates for a timeline and IOC register.
- `EVIDENCE_INDEX.md` — evidence handling and documentation guide.

## Important
This pack contains templates and investigation documentation only. It does **not** contain original malware, malicious Office documents, LNK files, executable payloads, credentials, or raw packet captures.

Populate the folders only with evidence you are authorised to share. Redact usernames, email addresses, public IPs, tokens, and unrelated personal information where appropriate. Record hashes for files you choose to publish.

See the case report in the GitHub repository:
`TryHackMe/Operation-Tempest/README.md`
