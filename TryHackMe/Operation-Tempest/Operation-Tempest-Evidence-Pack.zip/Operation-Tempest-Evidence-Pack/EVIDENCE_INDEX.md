# Evidence Index — Operation Tempest

| Evidence ID | Suggested filename | Evidence type | What it should demonstrate | Status |
|---|---|---|---|---|
| OT-IMG-001 | `process-investigation.png` | Screenshot | Relevant process/event-log finding | Not supplied |
| OT-IMG-002 | `startup-shortcut-finding.png` | Screenshot | Startup-folder shortcut finding | Not supplied |
| OT-IMG-003 | `http-c2-traffic.png` | Screenshot | Relevant HTTP traffic observation | Not supplied |
| OT-LOG-001 | `endpoint-event-summary.csv` | CSV export | Sanitised endpoint event records | Not supplied |
| OT-NET-001 | `network-analysis-notes.txt` | Text notes | Filters, observations, and conclusions | Not supplied |
| OT-IOC-001 | `verified-iocs.csv` | CSV | Indicators verified from lab evidence | Template only |

## Handling notes
- Do not include malware samples, malicious documents, shortcut files, scripts, or executable payloads.
- Prefer screenshots and text/CSV summaries over raw forensic artefacts.
- Do not fabricate timestamps, hashes, IP addresses, or event IDs.
- For every item, record its source, collection method, and a short explanation.
- Remove unrelated personal or sensitive information before publishing.
