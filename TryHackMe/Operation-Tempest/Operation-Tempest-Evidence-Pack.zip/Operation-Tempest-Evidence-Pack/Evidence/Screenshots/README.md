# Screenshots

Add only sanitised screenshots that support a specific finding in the case report.

Recommended screenshots:
1. Relevant process creation or endpoint event.
2. Startup-folder shortcut location (show the path, not the malicious file itself).
3. Wireshark view showing the relevant HTTP conversation and hostname/port where visible.

For each screenshot, add a short caption with the evidence ID, what it shows, and why it matters. Redact unrelated usernames, email addresses, tokens, and personal information.
