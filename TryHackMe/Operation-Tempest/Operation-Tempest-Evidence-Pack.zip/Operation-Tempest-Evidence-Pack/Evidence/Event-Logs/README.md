# Event Log Summaries

Add sanitised CSV or TXT exports of relevant event records. Include only the fields needed to support the finding, such as timestamp, host, event ID, process name, parent process, command-line context (after reviewing for secrets), and analyst note.

Do not upload full raw EVTX files unless you have reviewed them and confirmed they contain no sensitive information.
