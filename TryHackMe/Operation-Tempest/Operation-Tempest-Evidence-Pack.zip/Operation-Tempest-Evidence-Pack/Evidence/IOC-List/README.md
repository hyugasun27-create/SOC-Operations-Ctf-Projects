# Indicators of Compromise

Store only indicators confirmed from the lab evidence. Distinguish observed indicators from contextual references. Do not add guessed IP addresses, hashes, domains, or timestamps.
