# Network Analysis

Add concise text notes or sanitised screenshots from packet analysis.

Document:
- Capture filename and source (without publishing sensitive raw captures).
- Display filters used.
- Relevant protocol, hostname, URI, destination and port only when verified.
- What the traffic indicates and what remains uncertain.

Do not upload raw PCAP/PCAPNG files containing unrelated or sensitive traffic.
